﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using $safeprojectname$.Models;
using System.Runtime.Serialization;

namespace $safeprojectname$.Controllers
{
    [DataContract]
    [KnownType("Getalt_tbl1")]
    public class DropdownController : ApiController
    {
        VehicleEntities db = new VehicleEntities();
        
        public IQueryable Getalt_tbl1(int id)
        {
            db.Configuration.ProxyCreationEnabled = false;


            var loj = (from a in db.Alt_tbl
                       where a.modelid == id
                       select a).Distinct<Alt_tbl>();
           // IList<Item> ll = loj.GroupBy(x => x.name).select(x=>x);
            return loj;
        }
    }
}
