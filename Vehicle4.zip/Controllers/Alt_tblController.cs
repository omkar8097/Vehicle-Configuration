﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.Serialization;
using System.Web;
using System.Web.Http;
using $safeprojectname$.Models;

namespace $safeprojectname$.Controllers
{
    [KnownType(typeof($safeprojectname$.Models.Alt_tbl))]
    public class Alt_tblController : ApiController
    {
        private VehicleEntities db = new VehicleEntities();
        
        // GET api/Alt_tbl
        public IList<Config> GetAlt_tbl()
        {
            IList<Config> ll = new List<Config>();
            var alt_tbl = (from a in db.Alt_tbl
                                 join i in db.Items on a.itemid equals i.id into itemm
                                 from y in itemm.DefaultIfEmpty()
                                 join ii in db.Items on a.alt_itemid1 equals ii.id into alt_itemm
                                 from x in alt_itemm.DefaultIfEmpty()
                                 select new { id=y.id , item_name = y.name, alt_item = x.name, price = a.delta_price });
            foreach (var w in alt_tbl)
           {
               Config c = new Config();
               c.id = w.id;
               c.item_name = w.item_name;
               c.alt_item = w.alt_item;
               c.price = w.price;
               ll.Add(c);

           }
            return ll;
        }


       // GET api/Alt_tbl/5
        public IList<Config> GetAlt_tbl(int id)
        {
            

            IList<Config> ll = new List<Config>();
            var alt_tbl = (from a in db.Alt_tbl
                           join i in db.Items on a.itemid equals i.id into itemm
                           from y in itemm.DefaultIfEmpty()
                           join ii in db.Items on a.alt_itemid1 equals ii.id into alt_itemm
                           from x in alt_itemm.DefaultIfEmpty()
                           where a.modelid == id
                           select new { id = y.id, item_name = y.name, alt_item = x.name, price = a.delta_price });

            foreach (var w in alt_tbl)
            {   
                Config c = new Config();
                c.id = w.id;
                c.item_name = w.item_name;
                c.alt_item = w.alt_item;
                c.price = w.price;
                ll.Add(c);
            }

            List<Config> listObjects = (from obj in ll
                                         select obj).GroupBy(n => new { n.item_name })
                                           .Select(g => g.FirstOrDefault())
                                           .ToList();

            if (listObjects == null)
            {
                throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound));
            }

            return listObjects;
        }

        public IList<Config> GetAlt_tbl_item(int id , int mid)
        {


            IList<Config> ll = new List<Config>();
            var alt_tbl = (from a in db.Alt_tbl
                           join i in db.Items on a.itemid equals i.id into itemm
                           from y in itemm.DefaultIfEmpty()
                           join ii in db.Items on a.alt_itemid1 equals ii.id into alt_itemm
                           from x in alt_itemm.DefaultIfEmpty()
                           where a.modelid == id 
                           select new { id = y.id, item_name = y.name, alt_item = x.name, price = a.delta_price });

            foreach (var w in alt_tbl)
            {
                Config c = new Config();
                c.id = w.id;
                c.item_name = w.item_name;
                c.alt_item = w.alt_item;
                c.price = w.price;
                ll.Add(c);
            }

            List<Config> listObjects = (from obj in ll
                                        where obj.id == mid
                                        select obj).ToList();

            if (listObjects == null)
            {
                throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound));
            }

            return listObjects;
        }

        // PUT api/Alt_tbl/5
        public HttpResponseMessage PutAlt_tbl(int id, Alt_tbl alt_tbl)
        {
            if (!ModelState.IsValid)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
            }

            if (id != alt_tbl.id)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }

            db.Entry(alt_tbl).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
            }

            return Request.CreateResponse(HttpStatusCode.OK);
        }

        // POST api/Alt_tbl
        public HttpResponseMessage PostAlt_tbl(Alt_tbl alt_tbl)
        {
            if (ModelState.IsValid)
            {
                db.Alt_tbl.Add(alt_tbl);
                db.SaveChanges();

                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created, alt_tbl);
                response.Headers.Location = new Uri(Url.Link("DefaultApi", new { id = alt_tbl.id }));
                return response;
            }
            else
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
            }
        }

        // DELETE api/Alt_tbl/5
        public HttpResponseMessage DeleteAlt_tbl(int id)
        {
            Alt_tbl alt_tbl = db.Alt_tbl.Find(id);
            if (alt_tbl == null)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            db.Alt_tbl.Remove(alt_tbl);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
            }

            return Request.CreateResponse(HttpStatusCode.OK, alt_tbl);
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}