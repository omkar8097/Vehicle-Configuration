﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using $safeprojectname$.Models;


namespace $safeprojectname$.Controllers
{
    public class SelectController : ApiController
    {
        private VehicleEntities db = new VehicleEntities();
        List<Manufacturer> lm = new List<Manufacturer>();

        // GET api/Select
        public IEnumerable<Segment> GetSegments()
        {
            db.Configuration.ProxyCreationEnabled = false;
            return db.Segments.AsEnumerable();
        }



        // GET api/Select/2
        public IList<Manufacturer> GetManufacturer(int id )
        {
            db.Configuration.ProxyCreationEnabled = false;
            IEnumerable<Manufacturer> l = db.Manufacturers.AsEnumerable();
            IList<Manufacturer> lm = (from m in l
                                     where m.segmentid == id
                                     select m).ToList<Manufacturer>();
                       
           return lm;
        }


        // GET api/Select/?mid=2&sid=1
        public IList<Model> GetModel(int mid , int sid)
        {
            db.Configuration.ProxyCreationEnabled = false;
            
            List<Model> mod = db.Models.ToList();
            IList<Model> lm = (from mo in mod
                               where mo.segmentid == sid && mo.manufacturerid == mid
                               select mo).ToList<Model>();

            return lm ;
        }
    }
    }

