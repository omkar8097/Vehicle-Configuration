﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using $safeprojectname$.Models;

namespace $safeprojectname$.Controllers
{
    public class PriceController : ApiController
    {
        private VehicleEntities db = new VehicleEntities();
        
        // GET api/Alt_tbl
        public int Getprice(int id)
        {
            db.Configuration.ProxyCreationEnabled = false;

            Model m = db.Models.Find(id);
            if (m == null)
            {
                throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound));
            }
            int price = m.price;
            
            return price;
        }
    }

}
