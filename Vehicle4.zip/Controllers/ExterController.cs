﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using $safeprojectname$.Models;

namespace $safeprojectname$.Controllers
{
    public class ExterController : ApiController
    {
        VehicleEntities db = new VehicleEntities();

        public IList<Item> GetCore(int id)
        {
            db.Configuration.ProxyCreationEnabled = false;

            IList<Item> x = (from m in db.Model_detail
                             join i in db.Items
                             on m.itemid equals i.id
                             where m.modelid == id && m.model_config == "no" && m.model_type == "exter"
                             select i).ToList<Item>();
            return x;
        }
    }
}
