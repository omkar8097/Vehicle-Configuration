﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.Serialization;
using System.Web.Http;
using $safeprojectname$.Models;

namespace $safeprojectname$.Controllers
{
    [DataContract]
    [KnownType("GetAlt_tbl")]
    public class ConfController : ApiController
    {
        VehicleEntities db = new VehicleEntities();

        public IList<Config> GetAlt_tbl(int id)
        {
            db.Configuration.ProxyCreationEnabled = false;
            IList<Config> ll = new List<Config>();

           var loj = (from a in db.Alt_tbl
                                 join i in db.Items on a.itemid equals i.id into itemm
                                 from y in itemm.DefaultIfEmpty()
                                 join ii in db.Items on a.alt_itemid1 equals ii.id into alt_itemm
                                 from x in alt_itemm.DefaultIfEmpty()
                                 where a.modelid == id
                                 select new { item_name = y.name, alt_item = x.name, price = a.delta_price });
           foreach (var w in loj)
           {
               Config c = new Config();
               c.item_name = w.item_name;
               c.alt_item = w.alt_item;
               c.price = w.price;
               ll.Add(c);

           }
            return ll;
        }
        
       
    }
}
