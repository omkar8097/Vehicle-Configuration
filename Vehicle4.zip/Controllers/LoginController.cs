﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using $safeprojectname$.Models;


namespace $safeprojectname$.Controllers
{
    public class LoginController : ApiController
    {
        private VehicleEntities db = new VehicleEntities();

        public IList<Customer> validate(Customer o)
        {
            db.Configuration.ProxyCreationEnabled = false;
            List<Customer> l = db.Customers.ToList<Customer>();
            IList<Customer>  lm = (from c in l
                       where c.username == o.username && c.password == o.password
                       select c).ToList<Customer>();
            if (lm.Count == 0)
            {
                return null;
            }

            else
            {
                return lm;
            }
        }
        
    }
}
