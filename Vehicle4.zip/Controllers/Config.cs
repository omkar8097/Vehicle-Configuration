﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime;
using System.Web;

namespace $safeprojectname$.Controllers
{

    public class Config
    {
        public int id { get; set; }
        public string item_name { get; set; }
        public string alt_item { get; set; }
        public int price { get; set; }
    }
}