﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using $safeprojectname$.Models;
using System.Configuration;
using System.Runtime.Serialization;

namespace $safeprojectname$.Controllers
{
    public class DetailsController : ApiController
    {
        VehicleEntities db = new VehicleEntities();

        public IList<Item> GetCore(int id)
        {
            db.Configuration.ProxyCreationEnabled = false;

            IList<Item> x = (from m in db.Model_detail
                             join i in db.Items
                             on m.itemid equals i.id
                             where m.modelid == id && m.model_config == "no" && m.model_type=="core"
                             select i).ToList<Item>();
            return x;
        }

        
       
    }
}
