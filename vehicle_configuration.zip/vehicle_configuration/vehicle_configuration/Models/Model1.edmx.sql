
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, and Azure
-- --------------------------------------------------
-- Date Created: 01/16/2020 20:38:05
-- Generated from EDMX file: c:\users\yuvraj\documents\visual studio 2012\Projects\vehicle_configuration\vehicle_configuration\Models\Model1.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [vehicle_config];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------


-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------


-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Items'
CREATE TABLE [dbo].[Items] (
    [id] int IDENTITY(1,1) NOT NULL,
    [name] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'Model_detail1'
CREATE TABLE [dbo].[Model_detail1] (
    [id] int IDENTITY(1,1) NOT NULL,
    [model_type] nvarchar(max)  NOT NULL,
    [model_config] nvarchar(max)  NOT NULL,
    [itemid] int  NOT NULL,
    [modelid] int  NOT NULL
);
GO

-- Creating table 'Alt_tbl1'
CREATE TABLE [dbo].[Alt_tbl1] (
    [id] int IDENTITY(1,1) NOT NULL,
    [delta_price] nvarchar(max)  NOT NULL,
    [modelid] int  NOT NULL,
    [itemid] int  NOT NULL,
    [alt_itemid1] int  NOT NULL
);
GO

-- Creating table 'Models1'
CREATE TABLE [dbo].[Models1] (
    [id] int IDENTITY(1,1) NOT NULL,
    [model_name] nvarchar(max)  NOT NULL,
    [model_descip] nvarchar(max)  NOT NULL,
    [model_img] nvarchar(max)  NOT NULL,
    [mfg_date] nvarchar(max)  NOT NULL,
    [price] nvarchar(max)  NOT NULL,
    [manufacturerid] int  NOT NULL,
    [segmentid] int  NOT NULL
);
GO

-- Creating table 'Manufacturers'
CREATE TABLE [dbo].[Manufacturers] (
    [id] int IDENTITY(1,1) NOT NULL,
    [segmentid] int  NOT NULL,
    [manu_name] nvarchar(max)  NOT NULL,
    [manu_adrr] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'Customers'
CREATE TABLE [dbo].[Customers] (
    [id] int IDENTITY(1,1) NOT NULL,
    [c_name] nvarchar(max)  NOT NULL,
    [c_addr] nvarchar(max)  NOT NULL,
    [email] nvarchar(max)  NOT NULL,
    [telephone] nvarchar(max)  NOT NULL,
    [fax] nvarchar(max)  NOT NULL,
    [holding] nvarchar(max)  NOT NULL,
    [auth_person] nvarchar(max)  NOT NULL,
    [designation] nvarchar(max)  NOT NULL,
    [gst_no] nvarchar(max)  NOT NULL,
    [pan_no] nvarchar(max)  NOT NULL,
    [username] nvarchar(max)  NOT NULL,
    [password] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'Orders'
CREATE TABLE [dbo].[Orders] (
    [id] int IDENTITY(1,1) NOT NULL,
    [customerid] int  NOT NULL,
    [total_price] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'Admins'
CREATE TABLE [dbo].[Admins] (
    [id] int IDENTITY(1,1) NOT NULL,
    [username] nvarchar(max)  NOT NULL,
    [password] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'Segments'
CREATE TABLE [dbo].[Segments] (
    [id] int IDENTITY(1,1) NOT NULL,
    [seg_type] nvarchar(max)  NOT NULL,
    [min_qty] nvarchar(max)  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [id] in table 'Items'
ALTER TABLE [dbo].[Items]
ADD CONSTRAINT [PK_Items]
    PRIMARY KEY CLUSTERED ([id] ASC);
GO

-- Creating primary key on [id] in table 'Model_detail1'
ALTER TABLE [dbo].[Model_detail1]
ADD CONSTRAINT [PK_Model_detail1]
    PRIMARY KEY CLUSTERED ([id] ASC);
GO

-- Creating primary key on [id] in table 'Alt_tbl1'
ALTER TABLE [dbo].[Alt_tbl1]
ADD CONSTRAINT [PK_Alt_tbl1]
    PRIMARY KEY CLUSTERED ([id] ASC);
GO

-- Creating primary key on [id] in table 'Models1'
ALTER TABLE [dbo].[Models1]
ADD CONSTRAINT [PK_Models1]
    PRIMARY KEY CLUSTERED ([id] ASC);
GO

-- Creating primary key on [id] in table 'Manufacturers'
ALTER TABLE [dbo].[Manufacturers]
ADD CONSTRAINT [PK_Manufacturers]
    PRIMARY KEY CLUSTERED ([id] ASC);
GO

-- Creating primary key on [id] in table 'Customers'
ALTER TABLE [dbo].[Customers]
ADD CONSTRAINT [PK_Customers]
    PRIMARY KEY CLUSTERED ([id] ASC);
GO

-- Creating primary key on [id] in table 'Orders'
ALTER TABLE [dbo].[Orders]
ADD CONSTRAINT [PK_Orders]
    PRIMARY KEY CLUSTERED ([id] ASC);
GO

-- Creating primary key on [id] in table 'Admins'
ALTER TABLE [dbo].[Admins]
ADD CONSTRAINT [PK_Admins]
    PRIMARY KEY CLUSTERED ([id] ASC);
GO

-- Creating primary key on [id] in table 'Segments'
ALTER TABLE [dbo].[Segments]
ADD CONSTRAINT [PK_Segments]
    PRIMARY KEY CLUSTERED ([id] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [itemid] in table 'Model_detail1'
ALTER TABLE [dbo].[Model_detail1]
ADD CONSTRAINT [FK_ItemModel_detail]
    FOREIGN KEY ([itemid])
    REFERENCES [dbo].[Items]
        ([id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_ItemModel_detail'
CREATE INDEX [IX_FK_ItemModel_detail]
ON [dbo].[Model_detail1]
    ([itemid]);
GO

-- Creating foreign key on [modelid] in table 'Model_detail1'
ALTER TABLE [dbo].[Model_detail1]
ADD CONSTRAINT [FK_ModelModel_detail]
    FOREIGN KEY ([modelid])
    REFERENCES [dbo].[Models1]
        ([id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_ModelModel_detail'
CREATE INDEX [IX_FK_ModelModel_detail]
ON [dbo].[Model_detail1]
    ([modelid]);
GO

-- Creating foreign key on [modelid] in table 'Alt_tbl1'
ALTER TABLE [dbo].[Alt_tbl1]
ADD CONSTRAINT [FK_ModelAlt_tbl]
    FOREIGN KEY ([modelid])
    REFERENCES [dbo].[Models1]
        ([id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_ModelAlt_tbl'
CREATE INDEX [IX_FK_ModelAlt_tbl]
ON [dbo].[Alt_tbl1]
    ([modelid]);
GO

-- Creating foreign key on [manufacturerid] in table 'Models1'
ALTER TABLE [dbo].[Models1]
ADD CONSTRAINT [FK_ManufacturerModel]
    FOREIGN KEY ([manufacturerid])
    REFERENCES [dbo].[Manufacturers]
        ([id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_ManufacturerModel'
CREATE INDEX [IX_FK_ManufacturerModel]
ON [dbo].[Models1]
    ([manufacturerid]);
GO

-- Creating foreign key on [segmentid] in table 'Manufacturers'
ALTER TABLE [dbo].[Manufacturers]
ADD CONSTRAINT [FK_SegmentManufacturer]
    FOREIGN KEY ([segmentid])
    REFERENCES [dbo].[Segments]
        ([id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_SegmentManufacturer'
CREATE INDEX [IX_FK_SegmentManufacturer]
ON [dbo].[Manufacturers]
    ([segmentid]);
GO

-- Creating foreign key on [customerid] in table 'Orders'
ALTER TABLE [dbo].[Orders]
ADD CONSTRAINT [FK_CustomerOrder]
    FOREIGN KEY ([customerid])
    REFERENCES [dbo].[Customers]
        ([id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_CustomerOrder'
CREATE INDEX [IX_FK_CustomerOrder]
ON [dbo].[Orders]
    ([customerid]);
GO

-- Creating foreign key on [segmentid] in table 'Models1'
ALTER TABLE [dbo].[Models1]
ADD CONSTRAINT [FK_SegmentModel]
    FOREIGN KEY ([segmentid])
    REFERENCES [dbo].[Segments]
        ([id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_SegmentModel'
CREATE INDEX [IX_FK_SegmentModel]
ON [dbo].[Models1]
    ([segmentid]);
GO

-- Creating foreign key on [itemid] in table 'Alt_tbl1'
ALTER TABLE [dbo].[Alt_tbl1]
ADD CONSTRAINT [FK_ItemAlt_tbl]
    FOREIGN KEY ([itemid])
    REFERENCES [dbo].[Items]
        ([id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_ItemAlt_tbl'
CREATE INDEX [IX_FK_ItemAlt_tbl]
ON [dbo].[Alt_tbl1]
    ([itemid]);
GO

-- Creating foreign key on [alt_itemid1] in table 'Alt_tbl1'
ALTER TABLE [dbo].[Alt_tbl1]
ADD CONSTRAINT [FK_ItemAlt_tbl1]
    FOREIGN KEY ([alt_itemid1])
    REFERENCES [dbo].[Items]
        ([id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_ItemAlt_tbl1'
CREATE INDEX [IX_FK_ItemAlt_tbl1]
ON [dbo].[Alt_tbl1]
    ([alt_itemid1]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------