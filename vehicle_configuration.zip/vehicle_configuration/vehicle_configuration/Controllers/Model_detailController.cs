﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using vehicle_configuration.Models;

namespace vehicle_configuration.Controllers
{
    public class Model_detailController : ApiController
    {
        private Model1Container db = new Model1Container();

        // GET api/Model_detail
        public IEnumerable<Model_detail> GetModel_detail()
        {
            var model_detail1 = db.Model_detail1.Include(m => m.Item).Include(m => m.Model);
            return model_detail1.AsEnumerable();
        }

        // GET api/Model_detail/5
        public Model_detail GetModel_detail(int id)
        {
            Model_detail model_detail = db.Model_detail1.Find(id);
            if (model_detail == null)
            {
                throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound));
            }

            return model_detail;
        }

        // PUT api/Model_detail/5
        public HttpResponseMessage PutModel_detail(int id, Model_detail model_detail)
        {
            if (!ModelState.IsValid)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
            }

            if (id != model_detail.id)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }

            db.Entry(model_detail).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
            }

            return Request.CreateResponse(HttpStatusCode.OK);
        }

        // POST api/Model_detail
        public HttpResponseMessage PostModel_detail(Model_detail model_detail)
        {
            if (ModelState.IsValid)
            {
                db.Model_detail1.Add(model_detail);
                db.SaveChanges();

                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created, model_detail);
                response.Headers.Location = new Uri(Url.Link("DefaultApi", new { id = model_detail.id }));
                return response;
            }
            else
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
            }
        }

        // DELETE api/Model_detail/5
        public HttpResponseMessage DeleteModel_detail(int id)
        {
            Model_detail model_detail = db.Model_detail1.Find(id);
            if (model_detail == null)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            db.Model_detail1.Remove(model_detail);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
            }

            return Request.CreateResponse(HttpStatusCode.OK, model_detail);
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}