﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using vehicle_configuration.Models;

namespace vehicle_configuration.Controllers
{
    public class Alt_tblController : ApiController
    {
        private Model1Container db = new Model1Container();

        // GET api/Alt_tbl
        public IEnumerable<Alt_tbl> GetAlt_tbl()
        {
            var alt_tbl1 = db.Alt_tbl1.Include(a => a.Model).Include(a => a.Item).Include(a => a.Item1);
            return alt_tbl1.AsEnumerable();
        }

        // GET api/Alt_tbl/5
        public Alt_tbl GetAlt_tbl(int id)
        {
            Alt_tbl alt_tbl = db.Alt_tbl1.Find(id);
            if (alt_tbl == null)
            {
                throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound));
            }

            return alt_tbl;
        }

        // PUT api/Alt_tbl/5
        public HttpResponseMessage PutAlt_tbl(int id, Alt_tbl alt_tbl)
        {
            if (!ModelState.IsValid)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
            }

            if (id != alt_tbl.id)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }

            db.Entry(alt_tbl).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
            }

            return Request.CreateResponse(HttpStatusCode.OK);
        }

        // POST api/Alt_tbl
        public HttpResponseMessage PostAlt_tbl(Alt_tbl alt_tbl)
        {
            if (ModelState.IsValid)
            {
                db.Alt_tbl1.Add(alt_tbl);
                db.SaveChanges();

                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created, alt_tbl);
                response.Headers.Location = new Uri(Url.Link("DefaultApi", new { id = alt_tbl.id }));
                return response;
            }
            else
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
            }
        }

        // DELETE api/Alt_tbl/5
        public HttpResponseMessage DeleteAlt_tbl(int id)
        {
            Alt_tbl alt_tbl = db.Alt_tbl1.Find(id);
            if (alt_tbl == null)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            db.Alt_tbl1.Remove(alt_tbl);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
            }

            return Request.CreateResponse(HttpStatusCode.OK, alt_tbl);
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}