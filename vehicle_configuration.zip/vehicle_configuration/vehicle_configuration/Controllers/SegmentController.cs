﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using vehicle_configuration.Models;

namespace vehicle_configuration.Controllers
{
    public class SegmentController : ApiController
    {
        private Model1Container db = new Model1Container();

        // GET api/Segment
        public IEnumerable<Segment> GetSegments()
        {
            return db.Segments.AsEnumerable();
        }

        // GET api/Segment/5
        public Segment GetSegment(int id)
        {
            Segment segment = db.Segments.Find(id);
            if (segment == null)
            {
                throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound));
            }

            return segment;
        }

        // PUT api/Segment/5
        public HttpResponseMessage PutSegment(int id, Segment segment)
        {
            if (!ModelState.IsValid)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
            }

            if (id != segment.id)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }

            db.Entry(segment).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
            }

            return Request.CreateResponse(HttpStatusCode.OK);
        }

        // POST api/Segment
        public HttpResponseMessage PostSegment(Segment segment)
        {
            if (ModelState.IsValid)
            {
                db.Segments.Add(segment);
                db.SaveChanges();

                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created, segment);
                response.Headers.Location = new Uri(Url.Link("DefaultApi", new { id = segment.id }));
                return response;
            }
            else
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
            }
        }

        // DELETE api/Segment/5
        public HttpResponseMessage DeleteSegment(int id)
        {
            Segment segment = db.Segments.Find(id);
            if (segment == null)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            db.Segments.Remove(segment);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
            }

            return Request.CreateResponse(HttpStatusCode.OK, segment);
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}